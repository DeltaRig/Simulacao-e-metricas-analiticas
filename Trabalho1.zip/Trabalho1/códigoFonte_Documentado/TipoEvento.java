/**
 * Desenvolvedoras: Daniela Rigoli e Franciele Constante
 * Turma: 128
 * Professor: Afonso Sales
*/

enum TipoEvento {
    CHEGADA, PASSAGEM, SAIDA 
}