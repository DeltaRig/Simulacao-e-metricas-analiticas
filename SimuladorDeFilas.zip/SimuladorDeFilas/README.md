Desenvolvedoras: Daniela Rigoli e Franciele Constante

## Trabalho 1 - Parte 1

### Descrição:
Nessa primeira versão o projeto contém um gerador de números aleatórios e executa a simulação de uma fila simples recebendo os dados passados pelo usuário.

### Metas:
Pretende-se implementar para receber as variáveis de um arquivo, aumentar a complexidade das filas. 
Além disso, pretendemos que apareça no resultado final apenas estados da fila que ocorreram, ou seja, se a fila não passou de 3 pessoas os estados acima de 3 não serão exibidos.